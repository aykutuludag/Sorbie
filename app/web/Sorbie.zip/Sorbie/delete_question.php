<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
	
	$id = $_POST['id'];
		
	define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'granadag_sorbie');
		
		$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
		$sql = "DELETE FROM questions WHERE id= $id";
		
		if ($conn->query($sql) === TRUE) {
                    echo "Soru silindi";
        } else {
            echo "Error updating record: " . $sql->error;
        }
		mysqli_close($conn);
	} else {
		echo "Bir hata oluştu lütfen daha sonra tekrar deneyiniz...";
	}
?>