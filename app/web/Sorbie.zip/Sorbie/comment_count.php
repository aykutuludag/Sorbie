<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
	
	$id = $_POST['id'];
    $commentC = $_POST['comment_number'];
		
	define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'granadag_sorbie');
		
	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	$sql = "UPDATE questions SET comment_number = '$commentC' WHERE id = $id";
	if ($conn->query($sql) === TRUE) {
        echo "TESTTTTTTTT";
    } else {
         echo "Error updating record: " . $sql->error;
    }
	mysqli_close($conn);
	} else {
		echo "Bir hata oluştu lütfen daha sonra tekrar deneyiniz...";
	}
?>