<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){
		
	$image = $_POST['photo'];
    $name = $_POST['question'];
    $username = $_POST['username'];
    $user_photo = $_POST['user_photo'];
		
	define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'granadag_sorbie');
		
		$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
		
		$date = new DateTime();
		$timeStamp = $date->getTimestamp();
		$fileExt = ".jpeg";
		
	    $path = "uploads/".''.$timeStamp.''.$fileExt;
		$actualpath = "http://granadagame.com/Sorbie/$path";
		$sql = "INSERT INTO questions(photo,question,username,user_photo) VALUES ('$actualpath','$name', '$username', '$user_photo')";
		
		if(mysqli_query($conn,$sql)){
			file_put_contents($path,base64_decode($image));
			echo "Soru gönderildi...";
		}
		
		mysqli_close($conn);
	}else{
	    echo "Bir hata oluştu lütfen daha sonra tekrar deneyiniz...";
	}
?>