<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
	$id = $_POST['id'];
    $response = array();
    define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'granadag_sorbie');

    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    $sql = "SELECT * FROM comments WHERE question_id = '".$id."' ORDER BY time ASC";

    $result = $conn->query($sql) or die (mysqli_connect_error());
    if (!empty($result)) {
        // check for empty result
        if (mysqli_num_rows($result) > 0) {
            while($row = $result->fetch_array(MYSQL_ASSOC))
            {
                 $myArray[] = $row;
            }
            echo json_encode($myArray);
        } 
    }
	} else {
		echo "Bir hata oluştu. Lütfen daha sonra tekrar deneyiniz...";
	}
?>

