<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
	$username = $_POST['username'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $photo = $_POST['photo'];
    $gender = $_POST['gender'];
    $birthday = $_POST['birthday'];
    $location = $_POST['location'];
    $accType = $_POST['accType'];
		
	define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'granadag_sorbie');
		
	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	$sql = "INSERT INTO users(username,name,email,photo,gender,birthday,location,accType) VALUES ('$username','$name','$email','$photo','$gender','$birthday','$location','$accType')";
		
	if(mysqli_query($conn,$sql))
	{
		echo "Hesap oluşturuldu. Sorbie açılıyor, lütfen bekleyiniz...";
	}
	mysqli_close($conn);
	} else {
		echo "Error";
	}
?>