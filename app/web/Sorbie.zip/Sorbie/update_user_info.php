<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
	
	$username = $_POST['username'];
	$gender = $_POST['gender'];
	$birthday = $_POST['birthday'];
	$location = $_POST['location'];
	$job = $_POST['job'];
		
	define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'granadag_sorbie');
		
	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	$sql = "UPDATE users SET gender= '$gender', birthday= '$birthday', location= '$location', job= '$job' WHERE username= '".$username."'";
	if ($conn->query($sql) === TRUE) {
        echo "Bilgileriniz güncellendi...";
    } else {
        echo "Error updating record: " . $sql->error;
    }
	mysqli_close($conn);
	} else {
		echo "Bir hata oluştu lütfen daha sonra tekrar deneyiniz...";
	}
?>