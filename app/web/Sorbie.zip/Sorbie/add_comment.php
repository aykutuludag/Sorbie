<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
    $comment = $_POST['comment'];
    $question_id = $_POST['question_id'];
    $username = $_POST['username'];
    $userphoto = $_POST['user_photo'];
    
	define('DB_USERNAME', 'granadag_sorbieu');
    define('DB_PASSWORD', 'Rn5OD,[fGF$s');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'granadag_sorbie');
		
	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
	$sql = "INSERT INTO comments(comment,question_id,username,user_photo,isTrue) VALUES('$comment', '$question_id', '$username', '$userphoto', '0')";
		
	if(mysqli_query($conn,$sql))
	{
		echo "Yorumunuz gönderildi...";
	}
	mysqli_close($conn);
	} else {
		echo "Bir hata oluştu lütfen daha sonra tekrar deneyiniz...";
	}
?>